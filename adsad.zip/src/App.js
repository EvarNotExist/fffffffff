import {Select, Button, Tabs, Modal, Segmented, DatePicker, Input, Cascader, Table, Space, ConfigProvider, InputNumber } from 'antd';
import React, { useState } from 'react';
// import 'antd/dist/antd.css';
import { UserOutlined, CloseOutlined } from '@ant-design/icons';
import 'antd/dist/antd.min.css'
import './App.css';
import moment from 'moment';
import 'moment/locale/ru';
import locale from 'antd/es/locale/ru_RU';
const { TabPane } = Tabs;
const { Option } = Select;
const { TextArea } = Input;

function App() {
  return (
    <div>
      <ConfigProvider locale={locale}>
        <Tabs defaultActiveKey="1" type="card" size="large">
          <TabPane tab="&emsp;&emsp;&emsp;&emsp;&emsp;Записи&emsp;&emsp;&emsp;&emsp;&emsp;" key="1">
            <NotePage />
          </TabPane>
          <TabPane tab="Книги" key="2">
            <BookPage />
          </TabPane>
        </Tabs>
      </ConfigProvider>
    </div>
  );
};


function NotePage() {
  const [isModalVisible, setIsModalVisible] = useState(false);

  const showModal = () => {
    setIsModalVisible(true);

    return (<ShowModalDate />, <ShowModalDateLate />);
  };
  
  function ShowModalDate() {
    return <DatePicker className='valnow' locale={locale} format="D/MM/YYYY HH:mm" placeholder='Выберите дату' id='valDnow' defaultValue={moment()} showTime={{ format: 'HH:mm' }} />;
  };
  function ShowModalDateLate() {
    return <DatePicker className='valfuture' format="D/MM/YYYY HH:mm" placeholder='Выберите дату' id='valDfuture' defaultValue={moment().add(7,'days')} showTime={{ format: 'HH:mm' }} />;
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const options = [
    {
      value: '1',
      label: 'West',
    },
    {
      value: '2',
      label: 'Zh',
    },];

  const columns = [
    {
      title: 'Название',
      dataIndex: 'name',
      key: 'name',
      // render: (text) => <a>{text}</a>,
    },{
      title: 'Имя',
      dataIndex: 'emp',
      key: 'emp',
    },{
      title: 'Дата выдачи',
      dataIndex: 'dateOut',
      key: 'dateOut',
    },{
      title: 'Дата возврата',
      dataIndex: 'dateRet',
      key: 'dateRet',
    },{
      title: 'Действие',
      key: 'action',
      dataIndex: 'action',
      className: 'action',
      render: () => (
        <Space size="middle">
          <Button type="link">Возврат</Button>
        </Space>
      ),
    },
  ];

  const data = [
    {
      key: '1',
      name: 'John Brown',
      emp: 'J B',
      dateOut: 'New York No. 1',
      dateRet: 'Lake Park',
    },
  ];

  const onChange = () => {
    const actionItem = document.getElementsByClassName('action');
    var p = 0;
    if(actionItem[0].style.display === '' || actionItem[0].style.display === 'none'){
      for(p=0; p<actionItem.length; p++) actionItem[p].style.display = 'block';
    } else if(actionItem[0].style.display === 'block'){
      for(p=0; p<actionItem.length; p++) actionItem[p].style.display = 'none';
    }
  };

  return (
    <div>
      <div className="App">
        <div className="LineButtons">
          <Button type="primary" onClick={showModal}>Добавить</Button>
          <Button type="text" onClick={onChange}>Редактировать</Button>
          <div className="LineSwitch"><Segmented block options={['Текущие', 'История']} /></div>
        </div>
        <Modal className='modalNote' title="Добавить запись" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
          <table>
            <tbody>
              <tr>
                <td><p>Сотрудник</p></td>
                <td><Input className='inpuspick' placeholder='Выберите сотрудника' suffix={<UserOutlined />} /></td>
              </tr>
              <tr>
                <td><p>Книга</p></td>
                <td><Cascader className='casbook' placeholder="Выберите книгу" options={options} /></td>
              </tr>
              <tr>
                <td><p>Дата выдачи</p></td>
                <td><ShowModalDate /></td>
              </tr>
              <tr>
                <td><p>Дата возврата</p></td>
                <td><ShowModalDateLate /></td>
              </tr>
            </tbody>
          </table>
        </Modal>
      </div>
      <div>
        <Table className='tableNotes' columns={columns} dataSource={data} />;
      </div>
    </div>
  );
}

function BookPage() {
  const [formVisible, setFormVisible] = useState(false);

  const showForm = () => {
    if (!formVisible) {
      setFormVisible(true);
    } else if (formVisible) {
      setFormVisible(false);
    }
  };

  const columns = [
    {
      title: 'Название',
      dataIndex: 'name',
      key: 'name',
      // render: (text) => <a>{text}</a>,
    },{
      title: 'Автор',
      dataIndex: 'author',
      key: 'aut',
    },{
      title: 'Год',
      dataIndex: 'age',
      key: 'age',
    },{
      title: 'Теги',
      dataIndex: 'tags',
      key: 'tags',
    },{
      title: 'Количество',
      dataIndex: 'count',
      key: 'count',
    },{
      title: 'Действие',
      key: 'action',
      dataIndex: 'action',
      className: 'actionBook',
      render: () => (
        <Space size="middle">
          <Button type="link">Изменить</Button>
          <Button type="link">Удалить</Button>
        </Space>
      ),
    },
  ];

  const data = [
    {
      key: '1',
      name: 'John',
      author: 'John Brown',
      age: 'J B',
      tags: 'New York No. 1',
      count: 'Lake Park',
    },
  ];

  const onChangeBook = () => {
    const actionItem = document.getElementsByClassName('actionBook');
    var p = 0;
    if(actionItem[0].style.display === '' || actionItem[0].style.display === 'none'){
      for(p=0; p<actionItem.length; p++) actionItem[p].style.display = 'block';
    } else if(actionItem[0].style.display === 'block'){
      for(p=0; p<actionItem.length; p++) actionItem[p].style.display = 'none';
    }
  };

  return (
    <div>
      <div className="App">
        <div className="LineButtons bbook">
          <div>
            <Button type="primary" onClick={showForm}>Добавить</Button>
            <Button type="text" onClick={onChangeBook}>Редактировать</Button>
            <Input.Group compact style={{marginLeft: '100px'}}>
              <Select defaultValue="0" placeholder="Название">
                <Option disabled value="0">- Выбрать -</Option>
                <Option value="name">Название</Option>
                <Option value="author">Автор</Option>
                <Option value="tags">Теги</Option>
              </Select>
              <Input.Search style={{width: '300px'}} defaultValue="" placeholder="Поиск..." />
            </Input.Group>
          </div>
          { formVisible ? 
            <div className="formBook">
              <div>
                <div style={{display: 'flex'}}>
                  <h4>Добавить книгу</h4>
                  <Button style={{right: '-200px', top: '-5px', opacity: '0.5'}} type="text" onClick={showForm} ><CloseOutlined /></Button>
                </div>
                  <table>
                    <tbody>
                      <tr>
                        <td><p>Название:</p></td>
                        <td><Input placeholder="Название" /></td>
                      </tr>
                      <tr>
                        <td><p>Автор:</p></td>
                        <td><Input placeholder="Автор" /></td>
                      </tr>
                      <tr>
                        <td><p>Год:</p></td>
                        <td><Input placeholder="Год" /></td>
                      </tr>
                      <tr>
                        <td><p>Количество:</p></td>
                        <td><InputNumber style={{width: '250px', height: '33px', bottom: '0px', margin: '3px 0'}} placeholder="Количество" /></td>
                      </tr>
                      <tr>
                        <td><p>Теги:</p></td>
                        <td><TextArea style={{width: '250px'}} placeholder="Теги" autoSize={{ minRows: 2, maxRows: 6}} /></td>
                      </tr>
                    </tbody>
                  </table>
                <Button style={{margin: '3px 0', right: '-266px'}} type="primary">Добавить</Button>
              </div>
            </div>
          : null }
        </div>
      </div>
      <div>
        <Table className='tableBooks' columns={columns} dataSource={data} />;
      </div>
    </div>
  );
}

export default App;
